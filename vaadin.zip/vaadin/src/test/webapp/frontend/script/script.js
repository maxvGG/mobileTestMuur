function greet() {
    
};

greet();